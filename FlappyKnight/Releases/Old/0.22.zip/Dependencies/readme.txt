------------------------
THIS WILL ONLY SHOW ONCE
------------------------

Thanks for downloading my game!
Here are the controls for Flappy Knight:

Jump = Space
Glide = LCTRL (The CTRL or STRG button on the left side of your keyboard)
Change difficulty = 0 Key (only available if not playing)
Change Volume = LALT (The Alt key on the left side of your keyboard, only available if not playing)
Export Highscore file = RSHIFT (The SHIFT nutton on the right side of your keyboard)
Import Highscore file = ENTER

If you find any bugs or any other wrong things, direct message me on Discord (@Gaminguide1000) or on any other social media you know me on.
Have fun playing the game!